/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tugaspert11;
import java.awt.*;

/**
 *
 * @author Henry Lianto
 */
public class Latihan2 extends Panel{
    Font f;
    String text = "Halo Kharisma";
    Latihan2(){
        setBackground(Color.gray);
    }
        public void paint(Graphics g){
            f = new Font ("Helvetica",Font.BOLD,48);
            //Kotak Hijau
            g.setColor(Color.GREEN);
            g.fillRect(8,8,335,105);
            //Warna Hitam Pinggiran
            g.setColor(Color.BLACK);
            g.drawRect(8, 8, 335, 105);
            g.setColor(Color.pink);
            g.fillOval(10, 10, 330, 110);
            //pinggiran merah tebal
            g.setColor(Color.RED);
            g.drawOval(10, 10, 330, 100);
            g.drawOval(9, 9, 332, 102);
            g.drawOval(8, 8, 334, 104);
            // tulisan font helvetica
            g.setColor(Color.BLACK);
            g.setFont(f);
            g.drawString(text, 40, 75);
            
                    
        }
        public static void main(String[] args){
            Frame f=new Frame("Testing Graphics Panel");
            Latihan2 gp = new Latihan2();
            f.add(gp);
            f.setSize(900,900);
            f.setVisible(true);
        }
    }

