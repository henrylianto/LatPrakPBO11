/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package tugaspert11;

/**
 *
 * @author Henry Lianto
 */
import java.awt.*;
import java.awt.event.*;
public class HadiahTeoriPBO11 extends Frame implements ActionListener{
    int x = 100;
    int y = 100;
public static void main(String[] args) {
    HadiahTeoriPBO11 frame = new HadiahTeoriPBO11 ();
    frame.setSize(640, 480);
    frame.setVisible(true);
}
public HadiahTeoriPBO11() {
// end program when window is closed
    WindowListener l = new WindowAdapter()  {
    public void windowClosing(WindowEvent ev) {
    System.exit(0);
    }
    };
this.addWindowListener(l);
// mouse event handler
MouseListener mouseListener = new MouseAdapter() {
public void mouseClicked(MouseEvent ev) {
    x = ev.getX();
    y = ev.getY();
    repaint();
}
};
addMouseListener(mouseListener);
}

public void paint(Graphics g) {
setBackground (Color.GRAY);

    g.setColor(Color.white);
    //warna kepala
    g.setColor(Color.pink);
    g.fillOval(270, 150, 100, 80);
     g.setColor(Color.black);
    g.fillOval(288, 170, 20, 10);
    g.fillOval(319, 170, 20, 10);
    //Badan & Tangan
   g.drawLine(x +215,330,x +215,230);
   g.drawLine(x +140,270,x +300,270);
   //Kaki
   g.drawLine(x +300,400,x +215,330);
   g.drawLine(x +140,400,x +215,330);
   //rambut
   g.drawLine(x +150,170,x +175,170);
   g.drawLine(x +255,170,x +280,170);
   g.drawLine(x +235,153,x +260,143);
   g.drawLine(x +170,140,x +195,155);
   //mulut
    g.setColor(Color.red);
    g.drawArc(284,170,60,50,-10,-165);
}
public void actionPerformed(ActionEvent ev) {
String command = ev.getActionCommand();
if ("Close".equals(command)) {
System.exit(0);

}
}
}